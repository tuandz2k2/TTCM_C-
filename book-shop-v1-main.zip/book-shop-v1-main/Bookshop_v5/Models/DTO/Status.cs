﻿namespace Bookshop_v5.Models.DTO
{
    public class Status
    {
        public int StatusCode { get; set; }
        public string? Message { get; set; }
    }
}
