ASP.net core project !!!
Cách chạy database :
mở nuget package console
chạy lệnh :add-migration update
chạy lệnh :update-database
test develop 1
test 2

