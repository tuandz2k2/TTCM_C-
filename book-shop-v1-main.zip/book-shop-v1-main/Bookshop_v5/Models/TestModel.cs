﻿namespace Bookshop_v5.Models
{
    public class TestModel
    {
    }
}
